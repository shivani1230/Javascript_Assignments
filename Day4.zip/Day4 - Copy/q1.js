 function doSomething(){
     const img=document.getElementById("picture");
     img.src="736230.jpeg";
 }


function change(){
    const img=document.getElementById("picture");
    img.src="img2.jpg";
    }

function again(){
    const img=document.getElementById("picture");
    img.src="img3.jpg";
}

